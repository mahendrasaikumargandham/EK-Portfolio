import React from "react";
import { Instagram } from "@material-ui/icons";
import { Twitter } from "@material-ui/icons";
import { LinkedIn } from "@material-ui/icons";
import { GitHub } from "@material-ui/icons";

import "../styles/Footer.css";

function Footer() {
  return (
    <div className="footer">
      <div className="footer-align">
        <div className="socialMedia">
          <a href="https://github.com/eswarkartheekgrandhi" target="_blank">
            <GitHub />
          </a>
          <a href="https://instagram.com/kartheekgrandhi" target="_blank">
            <Instagram />
          </a>
          <a href="https://twitter.com/eswarkartheek1" target="_blank">
            <Twitter />
          </a>
          <a
            href="https://www.linkedin.com/in/eswar-kartheek-grandhi-bb1566214/"
            target="_blank"
          >
            <LinkedIn />
          </a>
        </div>
      </div>
      <div className="credits">
        <h3>
          Made with <span>❤</span> by Eswar Kartheek
        </h3>
      </div>
    </div>
  );
}

export default Footer;
