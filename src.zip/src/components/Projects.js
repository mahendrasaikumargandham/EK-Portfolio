import React from "react";
import Footer from "./Footer";

function Projects() {
  return (
    <div>
      Projects
      <Footer />
    </div>
  );
}

export default Projects;
